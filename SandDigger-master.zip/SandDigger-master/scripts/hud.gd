class_name Hud
extends CanvasLayer
## First-person HUD, built in code so the scene file stays readable.
##
## Shows level/XP, money, current equipment, carried loot, a crosshair, the
## contextual [E] prompt and short-lived flash messages. The metal detector is
## audio-only: it beeps faster and higher the closer the nearest junk is.
## Reads everything from PlayerState/LootManager groups, so it works unchanged
## when more players are added.

const GOLD := Color(1.0, 0.86, 0.42)

var _player: PlayerState
var _loot: LootManager

var _stats: Label
var _pocket: Label
var _crosshair: Label
var _prompt: Label
var _flash: Label

var _beep: AudioStreamPlayer
var _pings_left := 0
var _ping_timer := 0.0
var _ping_strength := 0.0
var _detector_status: Label
var _status_text := ""

var _flash_time := 0.0


func _ready() -> void:
	add_to_group("hud")
	layer = 10
	_build()
	await get_tree().process_frame
	_bind()


func _build() -> void:
	var root := Control.new()
	root.name = "Root"
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	_stats = _make_label(22, Color.WHITE)
	_stats.name = "Stats"
	_stats.position = Vector2(24, 20)
	_stats.text = "Loading..."
	root.add_child(_stats)

	_pocket = _make_label(18, GOLD)
	_pocket.name = "Pocket"
	_pocket.position = Vector2(24, 116)
	root.add_child(_pocket)

	_detector_status = _make_label(16, Color(0.8, 0.86, 0.95, 0.85))
	_detector_status.name = "DetectorStatus"
	_detector_status.position = Vector2(24, 148)
	root.add_child(_detector_status)

	_crosshair = _make_label(26, Color(1, 1, 1, 0.85))
	_crosshair.name = "Crosshair"
	_crosshair.text = "+"
	_crosshair.set_anchors_preset(Control.PRESET_CENTER)
	_crosshair.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_crosshair.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_crosshair.position += Vector2(-8, -18)
	root.add_child(_crosshair)

	_prompt = _make_label(22, Color.WHITE)
	_prompt.name = "Prompt"
	_prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_prompt.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_prompt.position += Vector2(-320, -190)
	_prompt.size = Vector2(640, 32)
	root.add_child(_prompt)

	_flash = _make_label(24, GOLD)
	_flash.name = "Flash"
	_flash.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_flash.set_anchors_preset(Control.PRESET_CENTER)
	_flash.position += Vector2(-320, 40)
	_flash.size = Vector2(640, 32)
	root.add_child(_flash)

	_build_detector_audio()

	var hint := _make_label(16, Color(1, 1, 1, 0.55))
	hint.name = "Hint"
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	hint.position += Vector2(-320, -32)
	hint.size = Vector2(640, 24)
	hint.text = "Click: dig   E: pick up / sell   F: detector (30 s)   U: upgrade   Arrows: look   Esc: mouse"
	root.add_child(hint)


## Builds a short sine "beep" in code, so the project needs no audio asset.
func _build_detector_audio() -> void:
	_beep = AudioStreamPlayer.new()
	_beep.name = "DetectorBeep"
	_beep.stream = _make_beep_stream()
	_beep.volume_db = -12.0
	add_child(_beep)


func _make_beep_stream() -> AudioStreamWAV:
	var rate := 22050
	var seconds := 0.075
	var sample_count := int(rate * seconds)
	var data := PackedByteArray()
	data.resize(sample_count * 2)
	for i in sample_count:
		var t := float(i) / float(rate)
		var envelope := sin(PI * float(i) / float(sample_count))
		var sample := sin(TAU * 900.0 * t) * envelope
		data.encode_s16(i * 2, int(clampf(sample, -1.0, 1.0) * 32000.0))
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.stereo = false
	stream.data = data
	return stream


func _make_label(font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	label.add_theme_constant_override("outline_size", 6)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label


func _bind() -> void:
	_player = get_tree().get_first_node_in_group("player_state") as PlayerState
	_loot = get_tree().get_first_node_in_group("loot_manager") as LootManager
	if _player != null:
		_player.xp_changed.connect(_on_any_changed)
		_player.money_changed.connect(_on_money_changed)
		_player.equipment_changed.connect(_on_equipment_changed)
		_player.carried_changed.connect(_on_carried_changed)
	refresh()


func _process(delta: float) -> void:
	if _flash_time > 0.0:
		_flash_time -= delta
		_flash.modulate.a = clampf(_flash_time / 0.4, 0.0, 1.0)
		if _flash_time <= 0.0:
			_flash.text = ""

	if _pings_left > 0:
		_ping_timer -= delta
		if _ping_timer <= 0.0:
			_fire_ping()
			_pings_left -= 1
			_ping_timer = 0.13 if _pings_left > 0 else 0.0


func refresh() -> void:
	if _player == null:
		return
	var equipment := _player.get_current_equipment()
	var next_index := _player.next_tier_index()
	var xp_needed := PlayerState.xp_required_for_level(_player.current_level + 1)
	var next_line := "MAX TIER"
	if next_index >= 0:
		var tier := _player.tiers[next_index]
		next_line = "Next: %s  (Lv %d / $%d)" % [
			tier.display_name, tier.level_required, int(tier.money_required)]
	_stats.text = "\n".join([
		"Lv %d   $%d   %s" % [_player.current_level, int(_player.current_money), equipment.display_name],
		"XP %.0f / %d" % [_player.current_xp, int(xp_needed)],
		next_line,
	])
	_pocket.text = "Pocket: %d item(s)  $%d  %s" % [
		_player.carried_loot.size(), int(_player.carried_value()),
		"(sell at the junkyard)" if not _player.carried_loot.is_empty() else "",
	]


func show_prompt(text: String) -> void:
	_prompt.text = text


func flash(text: String) -> void:
	_flash.text = text
	_flash_time = 2.4
	_flash.modulate.a = 1.0


## One detector use = a short three-beep sweep. It never shows a distance or a
## direction: the beeps just get higher and louder the closer the nearest junk.
func ping_detector() -> void:
	_ping_strength = detector_strength()
	_pings_left = 3
	_ping_timer = 0.0
	_fire_ping()
	_pings_left -= 1
	_ping_timer = 0.13


## Bottom-left status line driven by DigController (ready / recharging).
func set_detector_status(text: String) -> void:
	if text == _status_text:
		return
	_status_text = text
	_detector_status.text = text


## 0..1 reading of how close the nearest unclaimed junk is.
func detector_strength() -> float:
	if _loot == null:
		return 0.0
	var player := get_tree().get_first_node_in_group("player") as Node3D
	if player == null:
		return 0.0
	return _loot.signal_strength(player.global_position)


func _fire_ping() -> void:
	if _beep == null:
		return
	# Close = high and loud; nothing in range = a dull, quiet thud.
	_beep.pitch_scale = lerpf(0.7, 2.2, _ping_strength)
	_beep.volume_db = lerpf(-20.0, -2.0, _ping_strength)
	_beep.play()


func _on_any_changed(_a: Variant, _b: Variant) -> void:
	refresh()


func _on_money_changed(_money: float) -> void:
	refresh()


func _on_equipment_changed(_equipment: EquipmentData) -> void:
	refresh()


func _on_carried_changed(_count: int, _value: float) -> void:
	refresh()
